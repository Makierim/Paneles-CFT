﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Threading.Tasks;
using System.Text.Json;

namespace Paneles_CFT.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SolarProxyController : ControllerBase
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey = "AIzaSyD5ToidrAXpxR_glRnvnaEf_of4r7JXcEI";

        public SolarProxyController(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient();
        }

        [HttpGet("SolarData")]
        public async Task<IActionResult> GetSolarData(double lat, double lng)
        {
            string endpoint = $"https://solar.googleapis.com/v1/dataLayers:estimateSolarPotential?location.latitude={lat}&location.longitude={lng}&key={_apiKey}";

            try
            {
                Console.WriteLine($"Llamando a la API de Solar: {endpoint}");
                HttpResponseMessage response = await _httpClient.GetAsync(endpoint);
                response.EnsureSuccessStatusCode(); // Lanza una excepción si el código de estado no es exitoso
                string jsonResponse = await response.Content.ReadAsStringAsync();
                return Ok(jsonResponse); // Devuelve la respuesta de la API de Google al cliente
            }
            catch (HttpRequestException ex)
            {
                // Manejar los errores de solicitud HTTP
                return StatusCode((int)ex.StatusCode, ex.Message);
            }
            catch (Exception ex)
            {
                //Maneja otros errores
                return StatusCode(500, ex.Message);
            }
        }
    }
}